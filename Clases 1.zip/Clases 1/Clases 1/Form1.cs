﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Clases_1
{
    public partial class Form1 : Form
    {
        Plantilla Alumno = new Plantilla("Jorge","Torres","2605"); //OBJETO
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnNombrar_Click(object sender, EventArgs e)
        {
            Alumno.nombrar();
        }

        private void btnSiguiente_Click(object sender, EventArgs e)
        {
            Administrador frm2 = new Administrador();
            frm2.Show();
        }
    }
}
