﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clases_1
{
    public class Plantilla
    {
        string nombre;
        string apellido;
        string identificacion;


        public Plantilla(string n, string a, string i)
        {
            nombre = n;
            apellido = a;
            identificacion = i;
        }

        public void nombrar()
        {
            System.Windows.Forms.MessageBox.Show("El Nombres es : "+nombre);
         
        }
    }
}
