﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Formulario_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnAcerptar_Click(object sender, EventArgs e)
        {


            // try-catch
            try
            {
                //Byte texto = Convert.ToByte(txtIngreso.Text);
                //lblMostrar.Text = texto.ToString();

                if (txtIngreso.Text == "JorgeT" && txtContra.Text == "JT2torres")
                {
                    this.Hide();
                    Programa frm = new Programa();
                    frm.Show();
                    
                } 
                else
                {
                    MessageBox.Show("Usuario Incorrecto");
                }
            }
            catch (OverflowException y)
            {
                MessageBox.Show("El error es" + y);
            }
            catch (System.FormatException v )
            {
                MessageBox.Show("El error es" + v);
            }
        }

        private void btnSalier_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
