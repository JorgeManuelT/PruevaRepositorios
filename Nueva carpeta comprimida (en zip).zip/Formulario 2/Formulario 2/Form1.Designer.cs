﻿namespace Formulario_2
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtIngreso = new System.Windows.Forms.TextBox();
            this.btnAcerptar = new System.Windows.Forms.Button();
            this.lblMostrar = new System.Windows.Forms.Label();
            this.txtContra = new System.Windows.Forms.TextBox();
            this.btnSalier = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtIngreso
            // 
            this.txtIngreso.Location = new System.Drawing.Point(216, 48);
            this.txtIngreso.Name = "txtIngreso";
            this.txtIngreso.Size = new System.Drawing.Size(203, 26);
            this.txtIngreso.TabIndex = 0;
            // 
            // btnAcerptar
            // 
            this.btnAcerptar.Location = new System.Drawing.Point(216, 157);
            this.btnAcerptar.Name = "btnAcerptar";
            this.btnAcerptar.Size = new System.Drawing.Size(89, 32);
            this.btnAcerptar.TabIndex = 1;
            this.btnAcerptar.Text = "Aceptar";
            this.btnAcerptar.UseVisualStyleBackColor = true;
            this.btnAcerptar.Click += new System.EventHandler(this.btnAcerptar_Click);
            // 
            // lblMostrar
            // 
            this.lblMostrar.AutoSize = true;
            this.lblMostrar.Location = new System.Drawing.Point(142, 51);
            this.lblMostrar.Name = "lblMostrar";
            this.lblMostrar.Size = new System.Drawing.Size(68, 20);
            this.lblMostrar.TabIndex = 2;
            this.lblMostrar.Text = "Usuario:";
            // 
            // txtContra
            // 
            this.txtContra.Location = new System.Drawing.Point(216, 97);
            this.txtContra.Name = "txtContra";
            this.txtContra.Size = new System.Drawing.Size(203, 26);
            this.txtContra.TabIndex = 3;
            // 
            // btnSalier
            // 
            this.btnSalier.Location = new System.Drawing.Point(328, 157);
            this.btnSalier.Name = "btnSalier";
            this.btnSalier.Size = new System.Drawing.Size(75, 31);
            this.btnSalier.TabIndex = 4;
            this.btnSalier.Text = "Salir";
            this.btnSalier.UseVisualStyleBackColor = true;
            this.btnSalier.Click += new System.EventHandler(this.btnSalier_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(114, 100);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(96, 20);
            this.label1.TabIndex = 5;
            this.label1.Text = "Contraseña:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnSalier);
            this.Controls.Add(this.txtContra);
            this.Controls.Add(this.lblMostrar);
            this.Controls.Add(this.btnAcerptar);
            this.Controls.Add(this.txtIngreso);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtIngreso;
        private System.Windows.Forms.Button btnAcerptar;
        private System.Windows.Forms.Label lblMostrar;
        private System.Windows.Forms.TextBox txtContra;
        private System.Windows.Forms.Button btnSalier;
        private System.Windows.Forms.Label label1;
    }
}

