﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Formulario_2
{
    public partial class Programa : Form
    {
        public Programa()
        {
            InitializeComponent();
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            int nota1 = int.Parse(txtNota1.Text);
            int nota2 = int.Parse(txtNota2.Text);
            int nota3 = int.Parse(txtNota3.Text);
            int nota4 = int.Parse(txtNota4.Text);

            int Promedio = (nota1 + nota2);

            if (nota1 > 100)
            {
                MessageBox.Show("Nota1 no puede ser mayor a 100");
                if (nota2 > 100)
                {
                    MessageBox.Show("Nota2 no puede ser mayor a 100");
                    if (nota3 > 100)
                    {
                        MessageBox.Show("Nota3 no puede ser mayor a 100");
                        if (nota4 > 100)
                            MessageBox.Show("Nota4 no puede ser mayor a 100");
                    }
                }
            }
            else
            {
                lblPromedio.Text = Promedio.ToString();

                if (Promedio >= 60)
                {
                    lblPromedio.Text = ("Usted a aprovado, Felicidades");
                }
                else 
                {
                    lblPromedio.Text = ("Usted no a aprovado");
                }
            }
        }
    }
}
